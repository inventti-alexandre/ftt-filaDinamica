﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilaDinamica
{
    class Aluno
    {
        private int ra;
        private string nome;
        public int Ra
        {
            get { return ra; }
            set { ra = value; }
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
    }
}
