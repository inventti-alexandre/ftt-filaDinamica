﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PilhaDinamica
{
    public partial class Form1 : Form
    {
        Pilha pilha = new Pilha();
        public Form1()
        {
            InitializeComponent();
        }
        private void btnEmpilhar_Click(object sender, EventArgs e)
        {
            pilha.Empilhar(txtValor.Text);
            txtValor.Clear();
        }

        private void btnDesempilhar_Click(object sender, EventArgs e)
        {
            try
            {
                txtValor.Text = pilha.Desempilhar();
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message);
            }
        }
        private void btnTamanho_Click(object sender, EventArgs e)
        {
            MessageBox.Show(pilha.Quantidade.ToString());
        }
        private void btnRetornaTopo_Click(object sender, EventArgs e)
        {
            try
            {
                txtValor.Text = pilha.RetornaTopo();
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message);
            }
        }

        private void btnRetornarPilha_Click(object sender, EventArgs e)
        {
            try
            {
                txtValor.Text = pilha.RetornaPilha();
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message);
            }
        }
    }
}
