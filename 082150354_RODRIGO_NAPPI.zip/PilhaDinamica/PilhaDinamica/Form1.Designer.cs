﻿namespace PilhaDinamica
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtValor = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnEmpilhar = new System.Windows.Forms.Button();
            this.btnDesempilhar = new System.Windows.Forms.Button();
            this.btnRetornaTopo = new System.Windows.Forms.Button();
            this.btnTamanho = new System.Windows.Forms.Button();
            this.btnRetornarPilha = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtValor
            // 
            this.txtValor.Location = new System.Drawing.Point(12, 29);
            this.txtValor.Multiline = true;
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(286, 136);
            this.txtValor.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Valor";
            // 
            // btnEmpilhar
            // 
            this.btnEmpilhar.Location = new System.Drawing.Point(320, 26);
            this.btnEmpilhar.Name = "btnEmpilhar";
            this.btnEmpilhar.Size = new System.Drawing.Size(97, 23);
            this.btnEmpilhar.TabIndex = 2;
            this.btnEmpilhar.Text = "Empilha";
            this.btnEmpilhar.UseVisualStyleBackColor = true;
            this.btnEmpilhar.Click += new System.EventHandler(this.btnEmpilhar_Click);
            // 
            // btnDesempilhar
            // 
            this.btnDesempilhar.Location = new System.Drawing.Point(320, 55);
            this.btnDesempilhar.Name = "btnDesempilhar";
            this.btnDesempilhar.Size = new System.Drawing.Size(97, 23);
            this.btnDesempilhar.TabIndex = 3;
            this.btnDesempilhar.Text = "Desempilha";
            this.btnDesempilhar.UseVisualStyleBackColor = true;
            this.btnDesempilhar.Click += new System.EventHandler(this.btnDesempilhar_Click);
            // 
            // btnRetornaTopo
            // 
            this.btnRetornaTopo.Location = new System.Drawing.Point(320, 84);
            this.btnRetornaTopo.Name = "btnRetornaTopo";
            this.btnRetornaTopo.Size = new System.Drawing.Size(97, 23);
            this.btnRetornaTopo.TabIndex = 4;
            this.btnRetornaTopo.Text = "Retorna Topo";
            this.btnRetornaTopo.UseVisualStyleBackColor = true;
            this.btnRetornaTopo.Click += new System.EventHandler(this.btnRetornaTopo_Click);
            // 
            // btnTamanho
            // 
            this.btnTamanho.Location = new System.Drawing.Point(320, 113);
            this.btnTamanho.Name = "btnTamanho";
            this.btnTamanho.Size = new System.Drawing.Size(97, 23);
            this.btnTamanho.TabIndex = 5;
            this.btnTamanho.Text = "Tamanho";
            this.btnTamanho.UseVisualStyleBackColor = true;
            this.btnTamanho.Click += new System.EventHandler(this.btnTamanho_Click);
            // 
            // btnRetornarPilha
            // 
            this.btnRetornarPilha.Location = new System.Drawing.Point(320, 142);
            this.btnRetornarPilha.Name = "btnRetornarPilha";
            this.btnRetornarPilha.Size = new System.Drawing.Size(97, 23);
            this.btnRetornarPilha.TabIndex = 6;
            this.btnRetornarPilha.Text = "Retorna Pilha";
            this.btnRetornarPilha.UseVisualStyleBackColor = true;
            this.btnRetornarPilha.Click += new System.EventHandler(this.btnRetornarPilha_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 182);
            this.Controls.Add(this.btnRetornarPilha);
            this.Controls.Add(this.btnTamanho);
            this.Controls.Add(this.btnRetornaTopo);
            this.Controls.Add(this.btnDesempilhar);
            this.Controls.Add(this.btnEmpilhar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtValor);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEmpilhar;
        private System.Windows.Forms.Button btnDesempilhar;
        private System.Windows.Forms.Button btnRetornaTopo;
        private System.Windows.Forms.Button btnTamanho;
        private System.Windows.Forms.Button btnRetornarPilha;
    }
}

